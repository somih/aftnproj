SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


CREATE TABLE IF NOT EXISTS `AddrBook` (
  `IDUser` int(10) unsigned NOT NULL,
  `AddrName` varchar(250) NOT NULL,
  `Address` text NOT NULL,
  PRIMARY KEY (`IDUser`,`AddrName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `AddrBook` (`IDUser`, `AddrName`, `Address`) VALUES
(2, '', 'UKKACGXX '),
(2, '222', 'UKKKSITX   '),
(2, 'snowtam', 'UKKRYNYX UKLLZPZX UKLLBFXX'),
(2, 'wau mvt', 'UKKKSITX');

CREATE TABLE IF NOT EXISTS `Channels` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT '',
  `State` varchar(100) DEFAULT '',
  `Options` mediumtext,
  PRIMARY KEY (`ID`),
  KEY `id` (`ID`,`State`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

INSERT INTO `Channels` (`ID`, `Name`, `State`, `Options`) VALUES
(1, 'ИЦБ', '2', 'Device=/dev/ttyS0\nProtocolType=AFTN\nPortType=MTA\nCodeSet=MTK2\nMeteo=0\nMyCanelNameRU=ИЦБ\nMyCanelNameEN=ICB\nPeerCanelNameRU=ЦИБ\nPeerCanelNameEN=CIB\nMyAddressRU=УКЛЛБФЫЫ\nMyAddressEN=UKLLBFYY\nPeerAddressRU=УКЛЛЫФЫЫ\nPeerAddressEN=UKLLYFYY\nRuProtocol=1\nDebugLevel=10\nChSendIn=01,21,41\nChWaitFrom=2\nChWaitTo=2\nDigits=3\nOldProtocol=1\nAutoCorrectPDNum=0\nMyAdrMasks=*\n'),
(2, 'ИЦВ', '2', 'Device=/dev/ttyS0\nProtocolType=AFTN\nPortType=MTA\nCodeSet=MTK2\nMeteo=0\nMyCanelNameRU=ИЦВ\nMyCanelNameEN=ICW\nPeerCanelNameRU=ЦИВ\nPeerCanelNameEN=CIW\nMyAddressRU=УКЛЛЫФЫЫ\nMyAddressEN=UKLLBFYY\nPeerAddressRU=УКЛЛЫФЫЬ\nPeerAddressEN=UKLLYFYX\nRuProtocol=1\nDebugLevel=10\nChSendIn=01,21,41\nChWaitFrom=2\nChWaitTo=2\nDigits=3\nOldProtocol=1\nAutoCorrectPDNum=0\nMyAdrMasks=UKLL*\n');

CREATE TABLE IF NOT EXISTS `ChannelsStat` (
  `IDChannel` int(10) unsigned NOT NULL,
  `PD` int(10) unsigned DEFAULT '0',
  `PM` int(10) unsigned DEFAULT '0',
  `PDErr` int(10) unsigned DEFAULT '0',
  `PMErr` int(10) unsigned DEFAULT '0',
  `LastText` char(250) DEFAULT '',
  PRIMARY KEY (`IDChannel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `ChannelsStat` (`IDChannel`, `PD`, `PM`, `PDErr`, `PMErr`, `LastText`) VALUES
(1, 0, 0, 0, 0, 'Конец передачи сообщения'),
(8, 0, 0, 0, 0, 'Принят признак конца сообщения'),
(2, 0, 0, 0, 0, 'Принят признак конца сообщения');

CREATE TABLE IF NOT EXISTS `ChannelsStatLog` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IDChannel` int(10) unsigned NOT NULL,
  `DateStat` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `PDErr` int(10) unsigned DEFAULT '0',
  `PMErr` int(10) unsigned DEFAULT '0',
  `ErrText` char(200) DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `dat` (`IDChannel`,`DateStat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `Folders` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IDUser` int(11) NOT NULL,
  `FolderName` varchar(10) NOT NULL,
  `Masks` varchar(200) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

INSERT INTO `Folders` (`ID`, `IDUser`, `FolderName`, `Masks`) VALUES
(4, 1, 'Львов', 'УКЛЛ*');

CREATE TABLE IF NOT EXISTS `InBox` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Canal` int(10) unsigned NOT NULL DEFAULT '0',
  `DateIn` datetime DEFAULT '0001-01-01 00:00:00',
  `Head` varchar(100) DEFAULT '',
  `Adress` varchar(400) DEFAULT '',
  `Prior` varchar(100) DEFAULT '',
  `CreateTime` varchar(100) DEFAULT '',
  `FromAdress` varchar(100) DEFAULT '',
  `Mesg` mediumtext,
  PRIMARY KEY (`ID`),
  KEY `dat` (`DateIn`,`Canal`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `Logs` (
  `Canal` int(10) unsigned DEFAULT '0',
  `DateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Text` mediumtext,
  KEY `Dat` (`DateTime`,`Canal`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `OutBox` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `User` int(11) NOT NULL DEFAULT '0',
  `DataPost` datetime DEFAULT '0000-00-00 00:00:00',
  `DataSended` datetime DEFAULT '0000-00-00 00:00:00',
  `ToCanal` int(11) DEFAULT '0',
  `Status` int(10) unsigned DEFAULT '0',
  `Head` varchar(100) DEFAULT '',
  `Adress` varchar(400) DEFAULT '',
  `CreateTime` char(6) DEFAULT '',
  `FromAdress` char(8) DEFAULT '',
  `Prior` char(2) DEFAULT '',
  `Mesg` mediumtext,
  PRIMARY KEY (`ID`),
  KEY `DataUser` (`DataPost`,`User`),
  KEY `DatCanal` (`Status`,`ToCanal`,`DataPost`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `Storage` (
  `Canal` int(11) NOT NULL DEFAULT '0',
  `KeyName` varchar(100) NOT NULL DEFAULT '',
  `Val` mediumtext,
  PRIMARY KEY (`Canal`,`KeyName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `TemplBook` (
  `IDUser` int(10) unsigned NOT NULL,
  `TemplName` varchar(250) NOT NULL,
  `Address` text NOT NULL,
  `Template` text NOT NULL,
  `Prior` char(2) NOT NULL,
  PRIMARY KEY (`IDUser`,`TemplName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `TemplBook` (`IDUser`, `TemplName`, `Address`, `Template`, `Prior`) VALUES
(1, 'шаб2', 'UKBBYMYX UKHHYMYX\nГЛППРОДЖ', '1111ПРОБА ТЕКСТА ШАБЛОНА\nПРОБА ТЕКСТА ШАБЛОНА\n', 'Об'),
(1, 'УКЛЛБФЫЫ', 'UKBBYMYX UKHHYMYX\nГЛППРОДЖ', '1111ПРОБА ТЕКСТА ШАБЛОНА\nПРОБА ТЕКСТА ШАБЛОНА\n', 'KK'),
(2, 'snowtam', 'UKKRYNYX UKLLZPZX UKLLBFXX', 'SWUK171 UKLL 03201000\nSNOWTAM \nA)UKLL         B)03201000\nC)13         \nE)41           F)0/0/0        \nH)70/70/70  ATT-2         \nJ)60/2LR               \nL)TOTAL           \nN)1.6         \nR)1.6          S)03201100\nT)RWY CONTAMINATION 100 PERCENT', 'GG'),
(2, 'wau mvt', 'UKKKSITX', 'QX TSFAPXH BUDECW6 BUDFOW6 TSFKMXH ALLWGAZ TSFKBXH TSFKQXH\n\nTSFKPXH TSFKAXH\n\n.LWOARPS 290936\n\nMVT \n\nWU6798/29.URWUA.LWO \n\nAA0929/0935', 'GG'),
(2, 'LDM ВЕНЕЦІЯ', 'UKKKSITX', 'QU BUDFOW6 BUDECW6 TSFKMXH ALLWGAZ TSFKBXH TSFKQXH\n\n.LWOARPS 290833\n\nLDM\n\nWU6797/29.URWUB.Y180.2/4\n\n-TSF.68/81/11/0.T1478.3/1478\n\n.PAX/0/160.PAD/0/0\n\nSI TSF.B1478.CNIL.MNIL.ENIL\n\nB 112PCS\n\nSI', 'GG'),
(2, '1234656', 'UKKRYNYX UKLLZPZX UKLLBFXX', 'SWUK171 UKLL 03201000\nSNOWTAM \nA)UKLL         B)03201000\nC)13         \nE)41           F)0/0/0        \nH)70/70/70  ATT-2         \nJ)60/2LR               \nL)TOTAL           \nN)1.6         \nR)1.6          S)03201100\nT)RWY CONTAMINATION 100 PERCENT', 'GG'),
(2, 'ARR ВЕНЕЦІЯ', 'UKKKSITX ', 'QX TSFAPXH BUDECW6 BUDFOW6 TSFKMXH ALLWGAZ TSFKBXH TSFKQXH\n\nTSFKPXH TSFKAXH VCEAOXH\n\n.LWOARPS 290828\n\nMVT \n\nWU6798/29.URWUB.LWO \n\nAA0815/0822', 'GG'),
(2, 'wau ldm1', 'UKKKSITX', 'QU BUDFOW6 BUDECW6 TSFKMXH ALLWGAZ TSFKBXH TSFKQXH BGYKOXH BGYKWXH\n\nBGYAGXH\n\n.LWOARPS 081045\n\nLDM\n\nWU6797/08.URWUA.Y180.2/5\n\n-TSF.51/82/4/2.T1224.3/1224\n\n.PAX/0/137.PAD/0/0\n\nSI TSF.B1224.CNIL.MNIL.ENIL\n\nB 87PCS\n\nSI PLUS 2 INF', 'GG'),
(2, 'DEP ВЕНЕЦІЯ', 'UKKKSITX ', 'QX TSFAPXH BUDECW6 BUDFOW6 TSFKMXH ALLWGAZ TSFKBXH TSFKQXH\n\nTSFKPXH TSFKAXH\n\n.LWOARPS 290905\n\nMVT\n\nWU6797/29.URWUB.LWO \n\nAD0850/0901 EA1050 TSF\n\nDL 93/0020\n\nPX160\n\nSI', 'GG'),
(2, 'snowtam 1', 'UKKRYNYX UKLLZPZX ', 'SWUK191 UKLL 04030300\n\nSNOWTAM \n\nA)UKLL       B)04030300\n\nC)13         D)\n\nE)41         F)2/2/2        \n\nG)3/3/3      H)50/50/50  ATT-2         \n\nJ)30/2LR     K)     \n\nL)           M)\n\nN)2          P)\n\nR)2          S)04030430\n\nT)RWY CONTAMINATION 50 PERCENT', 'GG'),
(2, 'А Р К', 'UKKAYCYT', '1. 05.00 23.04.13-05.00 24.04.13\n\n2. МАКСЫМИВ И.С.\n\n3. 05.00 23.04.13-05.00 24.04.13\n\n4. АСК-32\n\n5. НПСГ-10\n\n6. ДЕЖУРНОГО ВС НЕТ\n\n7. СПЕЦТЕХНИКА-10\n\nРУКОВОДИТЕЛЬ АСР\n\n МАКСЫМИВ И.С.', 'GG'),
(2, 'літераА1', '', 'ОБРАЗЕЦ /ЗА 2 4АСА ДО .../ЗА 1 4АС ДО ...\n\n============================================\n\n\n\nАЭРОПОРТ БОРИСПОЛЬ ГОТОВ К ВЫЛЕТУ ЛИТЕРНОГО РЕЙСА\n\nUKN6202 =А= ПО МАРШРУТУ  БУДАПЕШТ - БОРИСПОЛЬ\n\n\n\n- СОСТОЯНИЕ ВПП - СУХАЯ / ПОКРЫТА ПО КРАЯМ НАКАТАМИ СНЕГА ДО 5ММ,                            \n- КОЕФИЦИЕНТ СЦЕПЛЕНИЯ 0.60\n- ЭФФЕКТИВНОСТЬ ТОРМОЖЕНИЯ / ХОРОШАЯ\n- ПРЕДПОЛАГАЕМЫЙ РАБОЧИЙ КУРС 13 ПР\n\n\n\nПОГОДА НА А/МЕ ЛЬВОВ\n\n29.03.13Г ЗА 12.00 UTC \n\nВЕТЕР 150 ГР 7 М/С\n\nУСЛОВИЯ \n\nВИДИМОСТЬ ГОРИЗОНТАЛЬНАЯ 10 КМ, ВЕРТИКАЛЬНАЯ 480 М\n\nТЕМПЕРАТУРА +1= \n\nОБРАЗЕЦ /ЗА 2 4АСА ДО .../ЗА 1 4АС ДО ...\n\n============================================\n\nСМЕННЫЙ СПЕЦИАЛИСТ ПО КОНТРОЛЮ ЗА НАЗЕМНИМ ОБСЛУЖИВАНИЕМ АМБРАХ И.В.', 'GG'),
(2, 'ARR МІЛАН', 'UKKKSITX ', 'QX  BUDECW6 BUDFOW6 BGYKOXH BGYKWXH BGYAGXH \n\nBGYAGXH\n\n.LWOARPS 131445\n\nMVT\n\nWU6782/13.URWUB.LWO \n\nAA1438/1445', 'GG'),
(2, 'LDM МІЛАН', 'UKKKSITX ', 'QU BGYKOXH BGYKWXH BGYAGXH BUDECW6\n\n.LWOARPS 131448\n\nLDM\n\nWU6781/13.URWUB.Y180.2/4\n\n-BGY.48/66/6/2.T1290.3/1290\n\n.PAX/0/120.PAD/0/0\n\nBGY.B1290.CNIL.MNIL.ENIL\n\nB 85PCS\n\nSI PLUS 2INF', 'GG'),
(2, 'DEP МІЛАН', 'UKKKSITX ', 'QN BGYKOXH BGYKWXH BGYAGXH BUDECW6\n\n.LWOARPS 131518\n\nMVT\n\nWU6781/13.URWUB.LWO\n\nAD1510/1622 EA1805 BGY\n\nDL93/0020\n\nPX120\n\nSI PLUS 2INF', 'GG'),
(2, 'кількість пас.', 'UKKACGXX ', 'НА ВАШУ ТЛГ 160918 УККАЦГЬЬ СООБЩАЕМ\nЗАГРУЗКА 02.04.2013\n\n1. ПРИБЫЛО ПАССАЖИРОВ 561+2ИНФ\n   ОТПРАВЛЕНО ПАССАЖИРОВ 660+9ИНФ\n2. ЗАДЕРЖАННЫЕ РЕГУЛЯРНЫЕ РЕЙСЫ: \n \n      \n НАКОПИТЕЛЬНАЯ ИНФОРМАЦИЯ ПО КОЛИ4ЕСТВУ ПРИБЫВШИХ И ОТПРАВЛЕННЫХ\nПАССАЖИРОВ \n  ДАТА  ?   К-ВО ПРИБЫВШИХ ПАС    К-ВО ОТПРАВЛЕННЫХ ПАС\n02.04.2013              561                   660\nВСЕГО С 01.04.2013      1142?              1370\nВСЕГО С 01.01.2013      48605?              53081\n\n\n\nКОНТАКТНАЯ ИНФОРМАЦИЯ ЛИЦ, ОТВЕТСТВЕННЫХ ЗА\nПРЕДОСТАВЛЕНИЕ ИНФОРМАЦИИ В ГОСАВИАСЛУЖБУ\n1. ДИРЕКТОР ПО ПРОИЗВОДСТВУ ГОРЯ4ЕВ А.Е. 050 3704585\n2. НА4.ВДСА КИРИК М.Р. 050 4301682\n \nС УВАЖЕНИЕМ, ПДСА ЛЬВОВ', 'GG'),
(2, 'ARR ДОРТМУНД', 'UKKKSITX   ', 'QX DTMAPXH DTMLLXH DTMLTXH BUDECW6 BUDFOW6 DTMLTXH BGYKOXH BGYKWXH\n\nBGYAGXH\n\n.LWOARPS 211429\n\nMVT\n\nWU6762/21.URWUB.LWO \n\nAA1422/1427', 'GG'),
(2, 'LDM ДОРТМУНД', 'UKKKSITX', 'QU BOOBOWF DTMLTXH DTMAPXH DTMLLXH BUDFOW6 BUDECW6 BGYAGXH\n\n.LWOARPS 211441\n\nLDM\n\nWU6761/21.URWUB.Y180.2/4\n\n-DTM.105/50/6/1.T1788.3/1788\n\n.PAX/0/161.PAD/0/0\n\nSI DTM.B1788.CNIL.MNIL.ENIL\n\nB 126PCS\n\nSI PLUS 1INF', 'GG'),
(2, 'DEP ДОРТМУНД', 'UKKKSITX', 'QN BOOBOWF DTMLTXH DTMAPXH DTMLLXH BUDFOW6 BUDECW6\n\n.LWOARPS 211513\n\nMVT\n\nWU6761/21.URWUB.LWO\n\nAD1457/1505 EA1650 DTM\n\nDL93/0017\n\nPX161\n\nSI PLUS 1INF\n\nDOORS CLOSED AT 1457', 'GG'),
(2, 'ARR PGT', 'UKKKSITX', 'ISTFPPC ISTOWPC SAWCOXH SAWOPPC ANKGMYF\n\n.LWOARPS 171243\n\nMVT\n\nPC634/17.TCCPI.LWO\n\nAA1236/1241', 'GG'),
(2, 'DEP PGT', 'UKKKSITX ', 'ISTFPPC ISTOWPC SAWCOXH SAWOPPC ANKGMYF LWOARPS\n\n.LWOARPS 171358\n\nMVT\n\nPC635/17.TCCPI.LWO\n\nAD1338/1351 EA1555 SAW\n\nPX171\n\nSI PLUS 1INF', 'GG'),
(2, 'LDM PGT', 'UKKKSITX ', 'QU ISTFPPC ISTOWPC SAWCOXH SAWOPPC ANKGMYF\n\n.LWOARPS 171354\n\nLDM\n\nPC635/17.TCCPI.Y189.2/4\n\n-SAW.90/78/3/1.T2228.2/805.3/1423\n\n.PAX/0/171.PAD/0/0\n\nSI SAW.B2228.CNIL.MNIL.ENIL\n\nB 150PCS\n\nSI PLUS 1 INF', 'GG'),
(2, 'APK SOROKA', 'УККАЫЦЫТ ', '1. 06.00 02.05.13-06.00 03.05.13\n\n2. СОРОКА Р.О.\n\n3. 06.00 02.05.13-06.00 03.05.13\n\n4. АСК-29\n\n5. НПСГ-10\n\n6. ДЕЖУРНОГО ВС НЕТ\n\n7. СПЕЦТЕХНИКА-10\n\nРУКОВОДИТЕЛЬ АСР\n\n СОРОКА Р.О.', 'GG'),
(2, 'літерний лво', 'UKKACWXX UKKACGXX UKLLBFYY', 'АЕРОПОРТ ЛЬВІВ ГОТОВИЙ БУТИ ЗАПАСНИМ ДЛЯ РЕЙСУ UKN6257 ''A'' \n\n10 ВЕРЕСНЯ 2013 РОКУ ПО МАРШРУТУ БОРИСПІЛЬ- ІВАНО-ФРАНКІВСЬК\n\nКСЦ 0,80\n\nДИСПЕТЧЕР КОСТЕРЕВА', 'GG'),
(2, 'NOTAM', 'UKKRYNYX UKLLZPZX UKLLBFXX', 'SWUK171 UKLL 03201000\nSNOWTAM \nA)UKLL         B)03201000\nC)13         \nE)41           F)0/0/0        \nH)70/70/70  ATT-2         \nJ)60/2LR               \nL)TOTAL           \nN)1.6         \nR)1.6          S)03201100\nT)RWY CONTAMINATION 100 PERCENT', 'GG'),
(2, 'NOTAM 2013', 'УККАЗГЗД УККРЫНЫЬ', 'ЗАПРОС НА ИЗДАНИЕ НОТАМ\nЩ)УКЛЖ\nА)УКЛЛ\nБ)1309271300\nЕ)ILS (LOC,GP) RWY31 РАБОТАЕТ. ПРОШУ ОТМЕНИТЬ НОТАМ С1766/13.\n \nГЕНЕРАЛЬНЫЙ ДИРЕКТОР      Р.П.ГОНТАРЕВ\n\nСОГЛАСОВАНО:\nЗАМ.ДИРЕКТОРА РСП ПО УВД  Н.И.ТОВСТИК', 'GG');

CREATE TABLE IF NOT EXISTS `UserBox` (
  `IDUser` int(10) unsigned NOT NULL DEFAULT '0',
  `IDMesg` int(10) unsigned NOT NULL DEFAULT '0',
  `Status` int(11) DEFAULT '0',
  `IDFolder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDUser`,`IDMesg`,`IDFolder`),
  KEY `UsFolder` (`IDUser`,`IDFolder`,`Status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Users` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `User` varchar(100) NOT NULL DEFAULT '',
  `Pass` varchar(100) DEFAULT '',
  `Addr` varchar(8) DEFAULT '',
  `Masks` mediumtext,
  `Status` varchar(100) NOT NULL DEFAULT '',
  `Statut` varchar(100) NOT NULL DEFAULT '2',
  `Level` int(11) NOT NULL,
  `Created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LastLogin` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `name` (`User`,`Pass`,`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

INSERT INTO `Users` (`ID`, `User`, `Pass`, `Addr`, `Masks`, `Status`, `Statut`, `Level`, `Created`, `LastLogin`) VALUES
(1, 'admin', 'admin', 'УКЛЛБФЫЫ', '*', '2', '2', 1, '2013-02-26 10:01:23', ''),
(2, 'user', 'user', 'УКЛЛБФЫЫ', '*', '2', '2', 0, '2013-01-25 09:58:05', ''),
(3, 'bonus', 'bonus', 'УКЛЛБФЫЫ', '*', '2', '2', 0, '2013-01-25 09:58:15', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
